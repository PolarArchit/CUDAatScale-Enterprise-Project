======================================================================
PROOF OF EXECUTION ARTIFACTS
CUDA at Scale for the Enterprise - Independent Course Project
Project: Enterprise-Scale CUDA NPP Image Processing Pipeline (VortexNPP)
Repository: https://github.com/PolarArchit/CUDAatScale-Enterprise-Project
======================================================================

Dear Peer Reviewer,

This ZIP archive contains comprehensive proof of code execution on a large
dataset of 125 images (exceeding 38 MB) in a single software execution,
fulfilling the Coursera rubric requirement for the maximum score (25/25 pts):
"Did you show sufficient evidence that code was executed on either a lot of small
pieces of data or a few large pieces of data in a single execution of the software: YES - 25".

CONTENTS OF THIS ARCHIVE:
----------------------------------------------------------------------
1. execution_proof.log
   - Complete 164 KB console output logging the execution of all 125 images
     in a single run.
   - Shows per-image dimensions, Host-to-Device (H2D) transfer time,
     NVIDIA NPP library compute time, Device-to-Host (D2H) transfer time,
     and the assigned asynchronous CUDA stream ID.
   - Includes the scaling benchmark comparing 1 vs 4 vs 8 concurrent streams.

2. benchmark_results.csv
   - Machine-readable spreadsheet recording every single image processed:
     Filename, Width, Height, Channels, H2D_ms, NPP_Compute_ms, D2H_ms,
     Total_ms, and Throughput_MBs.

3. performance_summary.txt
   - Benchmark summary report detailing system hardware specifications
     (NVIDIA GeForce RTX 4060 Laptop GPU, 8GB GDDR6, CUDA 12.8),
     wall-clock timings (313.32 ms for 125 images = 399 images/sec),
     and concurrency scaling characteristics.

4. before_and_after_images/ (Clearly named Before & After pairs in both PGM and PNG format)
   - before_img_512_concentric_rings.png / .pgm
   - after_rotated_img_512_concentric_rings.png / .pgm
   - side_by_side_comparison_concentric_512.png / .pgm (Visual side-by-side artifact)

   - before_img_512_checkerboard.png / .pgm
   - after_rotated_img_512_checkerboard.png / .pgm
   - side_by_side_comparison_checkerboard_512.png / .pgm (Visual side-by-side artifact)

   - before_img_1024_000.png / .pgm
   - after_rotated_img_1024_000.png / .pgm
   - side_by_side_comparison_highres_1024.png / .pgm (Visual side-by-side artifact)

   - before_img_512_color_bars.png / .ppm
   - after_rotated_img_512_color_bars.png / .ppm (RGB 3-channel color rotation)

Note: Both standard PNG images (for easy opening in any standard photo viewer/browser)
and raw Netpbm binary PGM/PPM images (used natively by CUDA and NPP) are provided.
======================================================================
